// Runs as part of `npm run build`, before `next build`.
//
// Applies the database schema and seed on PRODUCTION deploys only, so preview
// deployments and local builds never touch your live database.
//
//  • If prisma/migrations exists  → `prisma migrate deploy` (proper history)
//  • Otherwise                    → `prisma db push` (syncs schema directly).
//    db push refuses destructive changes without --accept-data-loss, so a bad
//    schema change fails the build instead of deleting data.
//  • The seed is idempotent and never overwrites content edited in the admin.
//
// Set PREPARE_DB=1 to force it outside production.
import { execSync } from "node:child_process";
import { existsSync } from "node:fs";

const isProduction = process.env.VERCEL_ENV === "production";
const forced = process.env.PREPARE_DB === "1";

if (!isProduction && !forced) {
  console.log("[prepare-db] Not a production deploy — skipping database setup.");
  process.exit(0);
}

function run(cmd) {
  console.log(`[prepare-db] ${cmd}`);
  execSync(cmd, { stdio: "inherit" });
}

if (existsSync("prisma/migrations")) {
  run("npx prisma migrate deploy");
} else {
  run("npx prisma db push --skip-generate");
}
run("npx prisma db seed");
