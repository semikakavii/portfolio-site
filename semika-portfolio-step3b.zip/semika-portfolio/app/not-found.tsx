import Link from "next/link";

export default function NotFound() {
  return (
    <main className="flex min-h-dvh flex-col justify-between px-6 py-8 md:px-12 md:py-10">
      <p className="text-[11px] uppercase tracking-[0.22em] text-fg-3">404</p>
      <h1 className="text-[clamp(3rem,11vw,10rem)] font-medium uppercase leading-[0.9] tracking-[-0.04em]">
        Nothing
        <br />
        here.
      </h1>
      <Link
        href="/"
        className="group w-fit text-[11px] uppercase tracking-[0.22em] text-fg-2 transition-colors hover:text-emerald-bright"
      >
        Back to home{" "}
        <span className="inline-block transition-transform group-hover:translate-x-1">→</span>
      </Link>
    </main>
  );
}
