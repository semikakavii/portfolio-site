import type { Metadata } from "next";
import { PageStub } from "@/components/ui/PageStub";

export const metadata: Metadata = { title: "Experiments" };

export default function Page() {
  return <PageStub label="Experiments" note="Placeholder — built in Step 5" />;
}
