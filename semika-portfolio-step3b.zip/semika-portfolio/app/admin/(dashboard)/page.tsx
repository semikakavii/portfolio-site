import { prisma } from "@/lib/db/prisma";
import { requireAdmin } from "@/lib/auth/session";

export const dynamic = "force-dynamic";

export default async function AdminOverview() {
  await requireAdmin();

  const [total, published, drafts, experiments, featured, activity] = await Promise.all([
    prisma.project.count({ where: { kind: "WORK" } }),
    prisma.project.count({ where: { kind: "WORK", publishStatus: "PUBLISHED" } }),
    prisma.project.count({ where: { kind: "WORK", publishStatus: "DRAFT" } }),
    prisma.experiment.count(),
    prisma.project.count({ where: { featured: true, publishStatus: "PUBLISHED" } }),
    prisma.activityLog.findMany({ orderBy: { createdAt: "desc" }, take: 8 }),
  ]);

  const stats = [
    ["Total work", total],
    ["Published", published],
    ["Drafts", drafts],
    ["Experiments", experiments],
    ["Featured", featured],
  ] as const;

  return (
    <div>
      <h1 className="text-2xl font-medium tracking-tight">Overview</h1>

      <dl className="mt-8 grid grid-cols-2 gap-px overflow-hidden rounded-md border border-line bg-line md:grid-cols-5">
        {stats.map(([label, value]) => (
          <div key={label} className="bg-canvas p-5">
            <dt className="text-[11px] uppercase tracking-[0.18em] text-fg-3">{label}</dt>
            <dd className="mt-2 text-3xl font-medium tabular-nums">{value}</dd>
          </div>
        ))}
      </dl>

      <h2 className="mt-12 text-sm font-medium text-fg-2">Recent activity</h2>
      {activity.length === 0 ? (
        <p className="mt-3 text-sm text-fg-3">No activity yet.</p>
      ) : (
        <ul className="mt-3 divide-y divide-line border-y border-line text-sm">
          {activity.map((a) => (
            <li key={a.id} className="flex items-baseline justify-between gap-4 py-3">
              <span>
                <span className="text-fg-3">{a.action}</span> {a.label}
              </span>
              <time className="text-fg-3" dateTime={a.createdAt.toISOString()}>
                {a.createdAt.toLocaleDateString("en-GB", { day: "numeric", month: "short" })}
              </time>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
