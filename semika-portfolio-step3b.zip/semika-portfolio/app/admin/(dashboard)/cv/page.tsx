import { requireAdmin } from "@/lib/auth/session";
import { AdminStub } from "@/components/admin/AdminStub";

export const metadata = { title: "CV" };

export default async function Page() {
  await requireAdmin();
  return <AdminStub title="CV" step="Step 7" />;
}
