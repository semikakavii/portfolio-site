import { requireAdmin } from "@/lib/auth/session";
import { AdminStub } from "@/components/admin/AdminStub";

export const metadata = { title: "Work" };

export default async function Page() {
  await requireAdmin();
  return <AdminStub title="Work" step="Step 7" />;
}
