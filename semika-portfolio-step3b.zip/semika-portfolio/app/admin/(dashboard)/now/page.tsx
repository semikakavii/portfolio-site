import { requireAdmin } from "@/lib/auth/session";
import { AdminStub } from "@/components/admin/AdminStub";

export const metadata = { title: "Now" };

export default async function Page() {
  await requireAdmin();
  return <AdminStub title="Now" step="Step 7" />;
}
