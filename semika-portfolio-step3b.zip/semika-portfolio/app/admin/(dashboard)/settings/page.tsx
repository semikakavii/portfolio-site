import { requireAdmin } from "@/lib/auth/session";
import { AdminStub } from "@/components/admin/AdminStub";

export const metadata = { title: "Settings" };

export default async function Page() {
  await requireAdmin();
  return <AdminStub title="Settings" step="Step 7" />;
}
