import { requireAdmin } from "@/lib/auth/session";
import { AdminStub } from "@/components/admin/AdminStub";

export const metadata = { title: "About" };

export default async function Page() {
  await requireAdmin();
  return <AdminStub title="About" step="Step 7" />;
}
