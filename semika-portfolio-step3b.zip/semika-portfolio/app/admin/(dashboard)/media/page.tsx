import { requireAdmin } from "@/lib/auth/session";
import { AdminStub } from "@/components/admin/AdminStub";

export const metadata = { title: "Media" };

export default async function Page() {
  await requireAdmin();
  return <AdminStub title="Media" step="Step 8" />;
}
