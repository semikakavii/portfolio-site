import { requireAdmin } from "@/lib/auth/session";
import { AdminSidebar } from "@/components/admin/AdminSidebar";

// Every page in this group is behind the admin check.
// Pages, server actions and route handlers still call requireAdmin() themselves.
export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const session = await requireAdmin();

  return (
    <div className="min-h-dvh md:grid md:grid-cols-[240px_1fr]">
      <AdminSidebar email={session.user.email} />
      <div className="px-6 py-8 md:px-10">{children}</div>
    </div>
  );
}
