import { requireAdmin } from "@/lib/auth/session";
import { AdminStub } from "@/components/admin/AdminStub";

export const metadata = { title: "Experiments" };

export default async function Page() {
  await requireAdmin();
  return <AdminStub title="Experiments" step="Step 7" />;
}
