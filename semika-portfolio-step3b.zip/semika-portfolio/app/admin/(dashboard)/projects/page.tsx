import { requireAdmin } from "@/lib/auth/session";
import { AdminStub } from "@/components/admin/AdminStub";

export const metadata = { title: "Projects" };

export default async function Page() {
  await requireAdmin();
  return <AdminStub title="Projects" step="Step 7" />;
}
