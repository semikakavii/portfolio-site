import { redirect } from "next/navigation";
import { getAdminSession } from "@/lib/auth/session";
import { LoginButton } from "@/components/admin/LoginButton";

const MESSAGES: Record<string, string> = {
  unable_to_create_user: "That Google account isn't authorised for this site.",
  access_denied: "Sign-in was cancelled.",
};

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  if (await getAdminSession()) redirect("/admin");

  const { error } = await searchParams;
  const message = error ? (MESSAGES[error] ?? "Sign-in failed. Try again.") : null;

  return (
    <main className="flex min-h-dvh items-center justify-center px-6">
      <div className="w-full max-w-sm">
        <p className="text-[11px] uppercase tracking-[0.22em] text-fg-3">Admin</p>
        <h1 className="mt-3 text-2xl font-medium tracking-tight">Sign in</h1>
        <p className="mt-2 text-sm text-fg-2">Use the Google account that was set up as admin.</p>
        {message ? (
          <p role="alert" className="mt-6 border-l border-emerald-muted pl-3 text-sm text-fg-2">
            {message}
          </p>
        ) : null}
        <div className="mt-8">
          <LoginButton />
        </div>
      </div>
    </main>
  );
}
