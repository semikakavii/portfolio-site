import type { Metadata } from "next";
import { PageStub } from "@/components/ui/PageStub";

export const metadata: Metadata = { title: "Now" };

export default function Page() {
  return <PageStub label="Now" note="Placeholder — built in Step 5" />;
}
