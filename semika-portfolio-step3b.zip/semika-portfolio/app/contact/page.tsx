import type { Metadata } from "next";
import { PageStub } from "@/components/ui/PageStub";

export const metadata: Metadata = { title: "Contact" };

export default function Page() {
  return <PageStub label="Contact" note="Placeholder — built in Step 5" />;
}
