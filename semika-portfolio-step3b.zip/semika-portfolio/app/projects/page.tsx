import type { Metadata } from "next";
import { PageStub } from "@/components/ui/PageStub";

export const metadata: Metadata = { title: "Projects" };

export default function Page() {
  return <PageStub label="Projects" note="Placeholder — built in Step 5" />;
}
