import { PageStub } from "@/components/ui/PageStub";

export default async function Page({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  return <PageStub label={slug} note="Project detail — built in Step 5" />;
}
