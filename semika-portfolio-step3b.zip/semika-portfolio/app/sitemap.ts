import type { MetadataRoute } from "next";
import { STATIC_ROUTES } from "@/lib/routes";

const base = (process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000").replace(/\/$/, "");

// Step 6 adds published projects and experiments from the database.
export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date();
  return STATIC_ROUTES.map((path) => ({
    url: `${base}${path === "/" ? "" : path}`,
    lastModified: now,
  }));
}
