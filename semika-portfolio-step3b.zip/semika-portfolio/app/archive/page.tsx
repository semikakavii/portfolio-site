import type { Metadata } from "next";
import { PageStub } from "@/components/ui/PageStub";

export const metadata: Metadata = { title: "Archive" };

export default function Page() {
  return <PageStub label="Archive" note="Placeholder — built in Step 5" />;
}
