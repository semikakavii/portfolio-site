import Link from "next/link";
import { STATIC_ROUTES } from "@/lib/routes";

// Temporary status page — replaced by the real homepage in Step 5.
export default function Home() {
  return (
    <main className="flex min-h-dvh flex-col justify-between px-6 py-8 md:px-12 md:py-10">
      <header className="flex items-start justify-between text-[11px] uppercase tracking-[0.22em] text-fg-3">
        <span>Semika</span>
        <span>Sri Lanka</span>
      </header>

      <h1 className="text-[clamp(3.5rem,15vw,14rem)] font-medium uppercase leading-[0.88] tracking-[-0.045em]">
        I make
        <br />
        things.
      </h1>

      <footer className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
        <p className="max-w-xs text-sm leading-relaxed text-fg-2">
          Scaffold is running. This page is a placeholder until the public site is built.
        </p>
        <nav aria-label="Route check">
          <ul className="flex flex-wrap gap-x-6 gap-y-2 text-[11px] uppercase tracking-[0.18em] text-fg-3">
            {STATIC_ROUTES.filter((r) => r !== "/").map((route) => (
              <li key={route}>
                <Link href={route} className="transition-colors hover:text-emerald-bright">
                  {route}
                </Link>
              </li>
            ))}
            <li>
              <Link href="/admin" className="transition-colors hover:text-emerald-bright">
                /admin
              </Link>
            </li>
          </ul>
        </nav>
      </footer>
    </main>
  );
}
