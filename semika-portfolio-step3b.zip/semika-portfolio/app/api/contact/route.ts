import { NextResponse } from "next/server";

// Step 6: validate with Zod, rate-limit, honeypot, store ContactMessage, send email.
export async function POST() {
  return NextResponse.json({ error: "Not implemented yet." }, { status: 501 });
}
