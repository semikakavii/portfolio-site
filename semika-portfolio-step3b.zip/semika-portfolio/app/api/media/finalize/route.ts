import { NextResponse } from "next/server";
import { getAdminSession } from "@/lib/auth/session";

// Step 8. Shows the pattern every admin route handler follows:
// check the session on the server first, then do the work.
export async function POST() {
  const session = await getAdminSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  return NextResponse.json({ error: "Not implemented yet." }, { status: 501 });
}
