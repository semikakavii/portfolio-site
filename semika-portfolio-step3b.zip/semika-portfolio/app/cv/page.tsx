import type { Metadata } from "next";
import { PageStub } from "@/components/ui/PageStub";

export const metadata: Metadata = { title: "CV" };

export default function Page() {
  return <PageStub label="CV" note="Placeholder — built in Step 5" />;
}
