import type { Metadata } from "next";
import { PageStub } from "@/components/ui/PageStub";

export const metadata: Metadata = { title: "Work" };

export default function Page() {
  return <PageStub label="Work" note="Placeholder — built in Step 5" />;
}
