import type { Metadata } from "next";
import { PageStub } from "@/components/ui/PageStub";

export const metadata: Metadata = { title: "About" };

export default function Page() {
  return <PageStub label="About" note="Placeholder — built in Step 5" />;
}
