export const NAV_ITEMS = [
  { href: "/work", label: "Work" },
  { href: "/projects", label: "Projects" },
  { href: "/experiments", label: "Experiments" },
  { href: "/about", label: "About" },
] as const;

/** Every static public route. Dynamic [slug] routes are added from the DB in Step 6. */
export const STATIC_ROUTES = [
  "/",
  "/work",
  "/projects",
  "/experiments",
  "/about",
  "/now",
  "/cv",
  "/contact",
  "/archive",
] as const;
