import "server-only";
import { cache } from "react";
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { auth } from "@/lib/auth/auth";
import { isAdminEmail } from "@/lib/env";

/**
 * Returns the session only if the signed-in user is (still) an admin.
 * Deduplicated per request.
 */
export const getAdminSession = cache(async () => {
  const session = await auth.api.getSession({ headers: await headers() });
  if (!session || !isAdminEmail(session.user.email)) return null;
  return session;
});

/**
 * Use at the top of EVERY admin page, server action and route handler.
 * Never rely on layouts or middleware alone — server actions can be invoked
 * directly, so each one must re-check.
 */
export async function requireAdmin() {
  const session = await getAdminSession();
  if (!session) redirect("/admin/login");
  return session;
}
