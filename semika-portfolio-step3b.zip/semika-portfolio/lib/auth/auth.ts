import "server-only";
import { betterAuth } from "better-auth";
import { prismaAdapter } from "better-auth/adapters/prisma";
import { nextCookies } from "better-auth/next-js";
import { prisma } from "@/lib/db/prisma";
import { env, isAdminEmail } from "@/lib/env";

/**
 * Admin auth: Google OAuth only, restricted to ADMIN_EMAILS.
 *  • No passwords are stored → nothing to brute-force or reset.
 *  • Accounts can only be created for allow-listed, Google-verified emails.
 *  • Authorisation is re-checked on every request (see session.ts) — the
 *    allowlist stays the single source of truth even if it changes later.
 */
export const auth = betterAuth({
  baseURL: env().BETTER_AUTH_URL,
  secret: env().BETTER_AUTH_SECRET,
  database: prismaAdapter(prisma, { provider: "postgresql" }),
  socialProviders: {
    google: {
      clientId: env().GOOGLE_CLIENT_ID,
      clientSecret: env().GOOGLE_CLIENT_SECRET,
    },
  },
  session: {
    expiresIn: 60 * 60 * 24 * 7, // 7 days
    updateAge: 60 * 60 * 24, // refresh once a day
  },
  databaseHooks: {
    user: {
      create: {
        before: async (user) => {
          // Returning false aborts sign-up for anyone not on the allowlist.
          if (!isAdminEmail(user.email) || user.emailVerified !== true) return false;
          return { data: user };
        },
      },
    },
    session: {
      create: {
        // Also gate every new session, so removing an email from ADMIN_EMAILS
        // stops that person signing in again even if their user row exists.
        before: async (session) => {
          const user = await prisma.user.findUnique({
            where: { id: session.userId },
            select: { email: true },
          });
          if (!user || !isAdminEmail(user.email)) return false;
          return { data: session };
        },
      },
    },
  },
  plugins: [nextCookies()], // keep last
});
