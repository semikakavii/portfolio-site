import { z } from "zod";

/** http(s) only — blocks javascript:, data:, etc. */
export const safeUrl = z
  .string()
  .trim()
  .url()
  .max(2048)
  .refine((u) => /^https?:\/\//i.test(u), "Only http(s) links are allowed");

/** Tiptap document. Rendered through a whitelist renderer, never as raw HTML. */
export const richText = z
  .object({
    type: z.literal("doc"),
    content: z.array(z.unknown()).optional(),
  })
  .passthrough();

export const creditSchema = z.object({
  role: z.string().trim().min(1).max(80),
  name: z.string().trim().min(1).max(120),
});

export const collaboratorSchema = z.object({
  name: z.string().trim().min(1).max(120),
  role: z.string().trim().max(80).optional(),
  url: safeUrl.optional(),
});

export const linkSchema = z.object({
  label: z.string().trim().min(1).max(60),
  url: safeUrl,
});

export const credits = z.array(creditSchema).max(50);
export const collaborators = z.array(collaboratorSchema).max(50);
