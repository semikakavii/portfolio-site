import type { VideoProvider } from "@prisma/client";

/**
 * Providers sit behind this small contract so the app never depends on one
 * vendor. Adapters (YouTube, Vimeo, Mux, Cloudflare Stream, file) arrive in Step 8.
 */
export interface VideoProviderAdapter {
  provider: VideoProvider;
  /** Extract the provider's canonical id from a pasted URL, or null if it isn't one. */
  parse(input: string): string | null;
  /** Embed URL for the click-to-load facade. */
  embedUrl(ref: string): string;
  /** Poster/thumbnail if the provider offers a predictable one. */
  thumbnailUrl?(ref: string): string | null;
}
