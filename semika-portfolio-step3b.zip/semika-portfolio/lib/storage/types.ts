import type { MediaKind } from "@prisma/client";

/**
 * Upload policy — the single source of truth used by both the signing
 * endpoint and the finalize step. Types are verified server-side by magic
 * bytes, never by filename or client-supplied MIME alone.
 */
export const UPLOAD_POLICIES: Record<
  MediaKind,
  { allowedMime: readonly string[]; maxBytes: number }
> = {
  IMAGE: {
    allowedMime: ["image/jpeg", "image/png", "image/webp", "image/avif"],
    maxBytes: 25 * 1024 * 1024,
  },
  VIDEO: {
    // Short loops / previews only. Long films belong on a video provider.
    allowedMime: ["video/mp4", "video/webm"],
    maxBytes: 100 * 1024 * 1024,
  },
  PDF: {
    allowedMime: ["application/pdf"],
    maxBytes: 15 * 1024 * 1024,
  },
};

/** Public URL for a stored object. Key-only in the DB → CDN domain can change freely. */
export function mediaUrl(storageKey: string): string {
  const base = process.env.NEXT_PUBLIC_MEDIA_URL?.replace(/\/$/, "") ?? "";
  return `${base}/${storageKey}`;
}
