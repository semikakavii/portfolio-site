import "server-only";
import { z } from "zod";

/**
 * Server-side environment, validated once on first use (not at import time),
 * so `prisma generate`, the seed script and pages that never touch auth or
 * storage can run without every secret being present.
 * Anything that imports lib/auth/auth.ts (auth routes, the admin) does need
 * the full set — including on the build machine.
 */
const schema = z.object({
  NEXT_PUBLIC_SITE_URL: z.string().url(),
  DATABASE_URL: z.string().url(),
  DIRECT_URL: z.string().url(),
  BETTER_AUTH_SECRET: z.string().min(32, "BETTER_AUTH_SECRET must be at least 32 characters"),
  BETTER_AUTH_URL: z.string().url(),
  GOOGLE_CLIENT_ID: z.string().min(1),
  GOOGLE_CLIENT_SECRET: z.string().min(1),
  ADMIN_EMAILS: z
    .string()
    .min(1)
    .transform((s) =>
      s
        .split(",")
        .map((e) => e.trim().toLowerCase())
        .filter(Boolean),
    ),

  // Optional until the steps that need them.
  NEXT_PUBLIC_MEDIA_URL: z.string().url().optional().or(z.literal("").transform(() => undefined)),
  R2_ACCOUNT_ID: z.string().optional(),
  R2_ACCESS_KEY_ID: z.string().optional(),
  R2_SECRET_ACCESS_KEY: z.string().optional(),
  R2_BUCKET: z.string().optional(),
  RESEND_API_KEY: z.string().optional(),
  CONTACT_FROM_EMAIL: z.string().optional(),
});

export type Env = z.infer<typeof schema>;

let cached: Env | undefined;

export function env(): Env {
  if (cached) return cached;
  const parsed = schema.safeParse(process.env);
  if (!parsed.success) {
    const problems = parsed.error.issues
      .map((i) => `  • ${i.path.join(".")}: ${i.message}`)
      .join("\n");
    throw new Error(
      `Invalid environment configuration. Check your .env against .env.example:\n${problems}`,
    );
  }
  cached = parsed.data;
  return cached;
}

/** Case-insensitive allowlist check. The ONLY source of admin authority. */
export function isAdminEmail(email: string | null | undefined): boolean {
  if (!email) return false;
  return env().ADMIN_EMAILS.includes(email.trim().toLowerCase());
}
