import type { z } from "zod";
import type { credits, collaborators, richText } from "@/lib/validation/content";

export type RichTextDoc = z.infer<typeof richText>;
export type Credit = z.infer<typeof credits>[number];
export type Collaborator = z.infer<typeof collaborators>[number];
