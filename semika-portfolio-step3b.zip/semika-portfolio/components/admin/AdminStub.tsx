export function AdminStub({ title, step }: { title: string; step: string }) {
  return (
    <div>
      <h1 className="text-2xl font-medium tracking-tight">{title}</h1>
      <p className="mt-2 text-sm text-fg-3">Not built yet — arrives in {step}.</p>
    </div>
  );
}
