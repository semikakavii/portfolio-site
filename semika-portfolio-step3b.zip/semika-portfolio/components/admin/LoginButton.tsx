"use client";

import { useState } from "react";
import { authClient } from "@/lib/auth/client";

export function LoginButton() {
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function signIn() {
    setPending(true);
    setError(null);
    const { error } = await authClient.signIn.social({
      provider: "google",
      callbackURL: "/admin",
      errorCallbackURL: "/admin/login",
    });
    if (error) {
      setError("Couldn't start sign-in. Check the auth settings in .env and try again.");
      setPending(false);
    }
  }

  return (
    <>
      <button
        type="button"
        onClick={signIn}
        disabled={pending}
        aria-busy={pending}
        className="w-full rounded-md border border-line px-4 py-3 text-sm transition-colors hover:border-emerald-muted hover:text-emerald-bright disabled:opacity-60"
      >
        {pending ? "Redirecting to Google…" : "Continue with Google"}
      </button>
      {error ? (
        <p role="alert" className="mt-4 text-sm text-fg-2">
          {error}
        </p>
      ) : null}
    </>
  );
}
