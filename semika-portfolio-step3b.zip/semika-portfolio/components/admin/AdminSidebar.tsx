"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { authClient } from "@/lib/auth/client";
import { cn } from "@/lib/utils/cn";

const ITEMS = [
  { href: "/admin", label: "Overview" },
  { href: "/admin/work", label: "Work" },
  { href: "/admin/projects", label: "Projects" },
  { href: "/admin/experiments", label: "Experiments" },
  { href: "/admin/media", label: "Media" },
  { href: "/admin/about", label: "About" },
  { href: "/admin/now", label: "Now" },
  { href: "/admin/cv", label: "CV" },
  { href: "/admin/settings", label: "Settings" },
] as const;

export function AdminSidebar({ email }: { email: string }) {
  const pathname = usePathname();

  async function signOut() {
    await authClient.signOut();
    window.location.href = "/admin/login";
  }

  return (
    <aside className="border-b border-line px-6 py-5 md:sticky md:top-0 md:h-dvh md:border-b-0 md:border-r md:py-8">
      <div className="flex items-baseline justify-between md:block">
        <Link href="/" className="text-sm font-medium tracking-tight">
          Semika <span className="text-fg-3">/ admin</span>
        </Link>
      </div>

      <nav aria-label="Admin" className="mt-4 md:mt-10">
        <ul className="flex flex-wrap gap-x-4 gap-y-1 md:flex-col md:gap-y-0.5">
          {ITEMS.map(({ href, label }) => {
            const active = href === "/admin" ? pathname === href : pathname.startsWith(href);
            return (
              <li key={href}>
                <Link
                  href={href}
                  aria-current={active ? "page" : undefined}
                  className={cn(
                    "block py-1.5 text-sm transition-colors",
                    active ? "text-emerald-bright" : "text-fg-2 hover:text-fg",
                  )}
                >
                  {label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      <div className="mt-6 md:absolute md:bottom-8 md:left-6 md:right-6 md:mt-0">
        <p className="truncate text-xs text-fg-3" title={email}>
          {email}
        </p>
        <button
          type="button"
          onClick={signOut}
          className="mt-2 text-xs text-fg-2 transition-colors hover:text-emerald-bright"
        >
          Sign out
        </button>
      </div>
    </aside>
  );
}
