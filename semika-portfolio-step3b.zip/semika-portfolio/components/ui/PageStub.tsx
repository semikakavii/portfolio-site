import Link from "next/link";

/** Temporary page body used by routes that are built in later steps. */
export function PageStub({ label, note }: { label: string; note: string }) {
  return (
    <main className="flex min-h-dvh flex-col justify-between px-6 py-8 md:px-12 md:py-10">
      <p className="text-[11px] uppercase tracking-[0.22em] text-fg-3">{note}</p>
      <h1 className="break-words text-[clamp(2.5rem,9vw,8rem)] font-medium uppercase leading-[0.92] tracking-[-0.04em]">
        {label}
      </h1>
      <Link
        href="/"
        className="w-fit text-[11px] uppercase tracking-[0.22em] text-fg-2 transition-colors hover:text-emerald-bright"
      >
        ← Home
      </Link>
    </main>
  );
}
