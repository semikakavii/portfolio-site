import { PrismaClient, type Prisma } from "@prisma/client";

const prisma = new PrismaClient();

/**
 * Idempotent, non-destructive seed: uses `update: {}` so re-running it never
 * overwrites anything edited in the admin.
 *
 * Only facts taken from the brief are seeded. Anything unknown (email, social
 * links, CV entries…) is left empty on purpose — the site hides empty fields
 * and the admin shows what's missing. Sample projects/experiments are added in
 * Step 5/6 and are flagged `isPlaceholder`.
 */
const CATEGORIES = [
  { slug: "film", name: "Film" },
  { slug: "cinematography", name: "Cinematography" },
  { slug: "photography", name: "Photography" },
  { slug: "design", name: "Design" },
  { slug: "motion", name: "Motion" },
  { slug: "digital", name: "Digital" },
];

const DISCIPLINES: Prisma.InputJsonValue = [
  { title: "Film" },
  { title: "Design" },
  { title: "Technology" },
  { title: "Brands" },
  { title: "Experiments" },
];

async function main() {
  for (const [sortOrder, c] of CATEGORIES.entries()) {
    await prisma.category.upsert({
      where: { slug: c.slug },
      update: {},
      create: { ...c, sortOrder },
    });
  }

  await prisma.siteSettings.upsert({
    where: { id: "singleton" },
    update: {},
    create: {
      id: "singleton",
      siteName: "Semika",
      descriptor: "Filmmaker · Creative Technologist · Builder",
      heroHeadline: "I MAKE\nTHINGS.",
      heroSubline: "Films, ideas, brands, experiments.",
      introText:
        "I work across filmmaking, design, technology and entrepreneurship — creating things that sit somewhere between visual storytelling and experimentation.",
      location: "Sri Lanka",
    },
  });

  await prisma.aboutContent.upsert({
    where: { id: "singleton" },
    update: {},
    create: {
      id: "singleton",
      headline: "I'm Semika.\nI make films, build things,\nand explore the space between\ntechnology and creativity.",
      disciplines: DISCIPLINES,
    },
  });

  await prisma.cv.upsert({
    where: { id: "singleton" },
    update: {},
    create: { id: "singleton" },
  });

  console.log("Seed complete: categories, site settings, about, cv.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
